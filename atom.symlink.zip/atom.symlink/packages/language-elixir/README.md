# language-elixir package

Elixir language support for Atom.

Adds syntax highlighting and snippets to Elixir files in Atom.

Copyright (c) 2014 [Plataformatec](http://plataformatec.com.br).
