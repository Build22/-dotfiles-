#!/bin/bash

echo $SHELL
