import sys
import os

print "CWD:{0}".format(os.getcwd())
print "ARGS:{0}".format(sys.argv[1:])
