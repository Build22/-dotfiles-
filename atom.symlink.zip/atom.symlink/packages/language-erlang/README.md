# language-erlang package

Erlang language support for Atom.

-----

Adds syntax highlighting and snippets to Erlang files in Atom.

Copyright (c) 2014 [Jonathan Barronville](mailto:jonathan@belairlabs.com "jonathan@belairlabs.com")
